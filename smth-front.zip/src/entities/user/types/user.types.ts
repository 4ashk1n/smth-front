export interface User {
    id: string
    username: string
    firstname: string
    lastname: string
    avatar: string
}