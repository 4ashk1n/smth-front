
class ArticleStore {
    
}