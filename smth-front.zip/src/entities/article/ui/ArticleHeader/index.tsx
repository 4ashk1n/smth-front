import { Stack, Text, Title } from "@mantine/core";
import type { CategoryColors } from "../../../category/types/category.types";
import { useArticleStore } from "../../contexts/article.context";
import UserPill from "../../../user/ui/UserPill";
import { observer } from "mobx-react-lite";
import HighlitedBlock from "../../../../shared/ui/blocks/HighlitedBlock";


const ArticleHeader: React.FC<{}> = observer(() => {
    const article = useArticleStore()
    console.log('bbb')
    return (<>
        <HighlitedBlock
            p={40}
            w='100%'
            h='100%'
            {...article.mainCategory.colors as CategoryColors}
            direction={'column'}
            justify={'space-between'}
            style={{
                zIndex: 10
            }}
        >

            <Stack gap={10}>
                <Title
                    order={1}
                    c={article.mainCategory.colors.lightColor}
                    fz={36}
                    lh={1}
                >
                    {article.title}
                </Title>

                <Text fz={20} c={article.mainCategory.colors.lightColor + '80'} lh={1}>
                    {article.description}
                </Text>
            </Stack>
            <UserPill size="md" user={article.author} />
        </HighlitedBlock>
    </>)
})

export default ArticleHeader;