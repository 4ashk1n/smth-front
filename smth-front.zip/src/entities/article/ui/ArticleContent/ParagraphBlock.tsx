import { Text } from "@mantine/core"
import Markdown from "react-markdown"
import { useArticleStore } from "../../contexts/article.context"
import type { Paragraph } from "../../types/content.types"
import HighlitedBlock from "../../../../shared/ui/blocks/HighlitedBlock"
import Object3dBlock from "./Object3dBlock"


const ParagraphBlock: React.FC<{ block: Paragraph }> = (props) => {
    const { mainCategory } = useArticleStore()

    const Paragraph2d = () => (<>
        {/* <HighlitedBlock style={{zIndex: 10}} p={40} w='100%' direction={'column'} gap={10} {...mainCategory.colors}> */}
            <Text fz={18} lh={'1.4'} fw={400} c='#ffffffdd'>
                <Markdown>{props.block.content}</Markdown>
            </Text>
        {/* </HighlitedBlock> */}
    </>)
    
    return (<> 
        {
            props.block.object3d ? 
                <Object3dBlock blocktype={'paragraph'} {...props.block.object3d} {...mainCategory.colors}>
                    <Paragraph2d />
                </Object3dBlock>
                : <Paragraph2d />
        }
    </>)
}

export default ParagraphBlock