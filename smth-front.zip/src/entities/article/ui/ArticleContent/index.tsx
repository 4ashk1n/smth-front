import ImageBlock from "./ImageBlock";
import IconBlock from "./IconBlock";

import { useArticleStore } from "../../contexts/article.context";
import type { Block, Icon, Image, Paragraph } from "../../types/content.types";
import { useIsMobileScreen } from "../../../../shared/lib/useIsMobile";
import ParagraphBlock from "./ParagraphBlock";
import { observer } from "mobx-react-lite";
import { useEffect } from "react";
import ReactGridLayout, { type Layout } from "react-grid-layout";
import ResponsiveGridLayout from "../../../../shared/ui/grids/ResponsiveGridLayout";

export const ArticleBlock = ({ block }: { block: Block }) => {
    return (<>
        {
            block.type === 'paragraph' ?
                <ParagraphBlock block={block as Paragraph} /> :
                block.type === 'image' ?
                    <ImageBlock block={block as Image} /> :
                    block.type === 'icon' ?
                        <IconBlock block={block as Icon} /> :
                        <></>
        }
    </>)
}

const ArticleContent: React.FC<{}> = observer(({ }) => {
    const article = useArticleStore()
    const isMobile = useIsMobileScreen();
    console.log(222)
    useEffect(() => {
        console.log(article.content.currentPage)
    }, [article.content.currentPageId])

    // console.log(article.content.map((block, i) => ({x: block.layout.x, y: block.layout.y, w: block.layout.w, h: block.layout.h, i: i, static: true})))
    return (<>
        {/* <Grid justify="center" align="center" columns={isMobile ? 1 :12} gutter={80} mt={80}>
            {article.content.rows.map((row, i) =>
                row.map((block, j) =>
                    <Grid.Col span={isMobile ? 1 : block.span} key={j}>
                            <ArticleBlock block={block} editMode={editMode} mainCategory={article.mainCategory} />
                    </Grid.Col>
                )
            )}
        </Grid> */}

        {/* <GridLayout
            className="layout"
            cols={12}
            rowHeight={250}
            width={1200}
            layout={article.content.map((block, i) => ({x: block.layout.x, y: block.layout.y, w: block.layout.w, h: block.layout.h, i: `${i}`, static: true}))}
        >
            {article.content.map((block, i) => 
            <div key={`${i}`} style={{height: 'fit-content'}}><ArticleBlock block={block} mainCategory={article.mainCategory} /></div>

            )}
        </GridLayout> */}

        <ResponsiveGridLayout
            className="layout"
            cols={{ lg: 2, md: 2, sm: 2, xs: 2, xxs: 1 }}
            rowHeight={180}
            compactType={null}
            containerPadding={{ lg: [0, 0], md: [0, 0], sm: [0, 0], xs: [0, 0] }}
            maxRows={4}
            margin={{ lg: [36, 18], md: [36, 18], sm: [36, 18], xs: [36, 18] }}
        >
            {
                article.content.currentPage?.blocks.map((block, i) =>
                    <div key={`${i}`} 
                        data-grid={{ 
                            x: block.layout.x, 
                            y: block.layout.y, 
                            w: block.layout.w, 
                            h: block.layout.h,
                            maxW: 2,
                            minW: 1,
                            maxH: 4,
                            minH: 1,
                            static: true
                        } as Layout} 
                        style={{ height: 'fit-content' }}>
                        <ArticleBlock block={block} />
                    </div>
                )
            }
        </ResponsiveGridLayout>

    </>)
});

export default ArticleContent;