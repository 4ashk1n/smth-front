import type { Article, ArticleDTO } from "../types/article.types";

export const ARTICLE_DTO_SAMPLE: ArticleDTO = {
    id: '1',
    title: 'Наш слон',
    description: 'Мы взяли интервью у Павла Дурова',
    mainCategory: {
        id: '1',
        emoji: '🐘',
        name: 'Slon',
        colors: {
            lightColor: '#F9EBEA',
            darkColor: '#145A32',
            accentColor: '#B03A2E'
        }
    },
    categories: [{
        id: '1',
        emoji: '🐘',
        name: 'Slon',
        colors: {
            lightColor: '#F9EBEA',
            darkColor: '#145A32',
            accentColor: '#B03A2E'
        }
    }],
    status: 'published',
    author: {
        id: '1',
        firstname: 'skebob',
        lastname: 'abob',
        username: 'zverinus',
        avatar: 'https://fbi.cults3d.com/uploaders/34973218/illustration-file/46f9a2d8-fb9a-482f-9b9f-8ba3c0701b6d/skiebob.jpg'
    },
    content: {
        topics: [
            {
                id: '1',
                title: 'Кто такой Дуров и почему он до сих пор на хайпе?',
                pages: [
                    {
                        id: '1',
                        blocks: [
                            {
                                id: '1',
                                type: 'paragraph',
                                content: 'Павел Дуров — это не просто основатель ВКонтакте и Telegram. Это человек, который выбрал путь одиночки, отказался от миллиардов и убежал от всего, что его ограничивало. У него нет дома, нет гражданства, нет офиса. Зато есть миллионы пользователей и чёткая позиция — свобода личных данных превыше всего. Мы встретились с Павлом онлайн. Он отвечал голосом, но без камеры. Фоном был глухой ветер и иногда слышался шум моря.',
                                layout: {
                                    i: '0',
                                    x: 0,
                                    y: 0,
                                    w: 1,
                                    h: 2
                                }
                            },
                            {
                                id: '2',
                                type: 'image',
                                url: 'https://s0.rbk.ru/v6_top_pics/media/img/5/27/347495348582275.jpeg',
                                source: 'РБК',
                                label: 'Павел Дуров сидит',
                                object3d: {
                                    depth: 5,
                                    translateX: 0,
                                    translateY: 0,
                                    translateZ: 3,
                                    rotateX: 5,
                                    rotateY: 10,
                                    rotateZ: 0,
                                    scale: 1
                                },
                                layout: {
                                    i: '1',
                                    x: 1,
                                    y: 0,
                                    w: 1,
                                    h: 1
                                }
                            },
                        ],
                        topicId: '1',
                        order: 0
                    }
                ],
                order: 0
            }
        ]
    }
}