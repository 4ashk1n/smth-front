import type { Block, Content, Page, Topic } from "../types/content.types";
import { makeAutoObservable, ObservableMap } from "mobx";

export class ContentStore {
    topics: ObservableMap<string, Topic> = new ObservableMap();
    pages: ObservableMap<string, Page> = new ObservableMap();
    blocks: ObservableMap<string, Block> = new ObservableMap();

    currentPageId: string = ''

    constructor() {
        makeAutoObservable(this, {}, { autoBind: true })
    }

    fromDTO(content: Content) {
        this.topics = new ObservableMap(content.topics.map(t => [t.id, t]));
        this.pages = new ObservableMap(content.topics.flatMap(t => t.pages.map(p => [p.id, p])));
        this.blocks = new ObservableMap(content.topics.flatMap(t => t.pages.flatMap(p => p.blocks.map(b => [b.id, b]))));

        this.currentPageId = content.topics[0].pages[0].id
    }

    get currentTopic(): Topic | undefined {
        return this.topics.get(this.currentPageId) ?? undefined;
    }

    get currentPage(): Page | undefined {
        return this.pages.get(this.currentPageId) ?? undefined;
    }

    
}