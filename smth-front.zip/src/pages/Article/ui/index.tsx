import { Stack, Grid } from "@mantine/core"
import ArticleStoreProvider from "../../../entities/article/contexts/article.context"
import { ARTICLE_DTO_SAMPLE } from "../../../entities/article/samples/article.sample"
import ArticleContent from "../../../entities/article/ui/ArticleContent"
import ArticleBackground from "../../../entities/article/ui/ArticleContent/ArticleBackground"
import ArticleHeader from "../../../entities/article/ui/ArticleHeader"
import ReactGridLayout from "react-grid-layout"
import ResponsiveGridLayout from "../../../shared/ui/grids/ResponsiveGridLayout"

const ArticlePage = () => {

    return (<>
        <ArticleStoreProvider article={ARTICLE_DTO_SAMPLE}>
            <ArticleBackground />
            <Stack align="center" w='100%' h='100%'>
                <div
                    style={{
                        position: 'relative',
                        width: '90%',
                        height: '100%',
                        zIndex: 1,
                        maxWidth: 1280
                    }}
                >
                    <ResponsiveGridLayout
                        cols={{ lg: 4, md: 4, sm: 2, xs: 1, xxs: 1 }}
                        rowHeight={180}
                        className="layout"
                        margin={{ lg: [36, 18], md: [36, 18], sm: [36, 18], xs: [36, 18] }}
                    >
                        <div key='header' data-grid={{ x: 0, y: 0, w: 1, h: 4, static: true }}>
                            <ArticleHeader />
                        </div>

                        <div key='content' data-grid={{ x: 1, y: 0, w: 2, h: 4, static: true }}>
                            <ArticleContent />
                        </div>
                    </ResponsiveGridLayout>
                </div>
            </Stack>
        </ArticleStoreProvider>

    </>)
}

export default ArticlePage